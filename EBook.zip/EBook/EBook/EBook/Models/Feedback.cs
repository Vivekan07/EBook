﻿using EBook.Data.Base;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EBook.Models
{
    public class Feedback : IEntityBase // Implement IEntityBase here
    {
        [Key]
        public int Id { get; set; } // Required by IEntityBase

        [Required]
        public int BookId { get; set; }

        [ForeignKey("BookId")]
        public Book Book { get; set; }

        [Required]
        public string UserId { get; set; }

        [ForeignKey("UserId")]
        public ApplicationUser User { get; set; }

        [Required]
        [StringLength(1000)]
        public string Comments { get; set; }

        [Range(1, 5)]
        public int Rating { get; set; }
    }
}
