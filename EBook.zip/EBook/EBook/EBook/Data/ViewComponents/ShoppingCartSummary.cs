﻿using EBook.Data.Cart;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace EBook.Data.ViewComponents
{
    public class ShoppingCartSummary : ViewComponent
    {
        private readonly ShoppingCart _shoppingCart;
        public ShoppingCartSummary(ShoppingCart shoppingCart)
        {
            _shoppingCart = shoppingCart;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var items = await _shoppingCart.GetShoppingCartItemsAsync();

            return View(items.Count);
        }
    }
}
