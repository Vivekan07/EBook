﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EBook.Data.ViewModels
{
    public class NewBookVM
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Book Name is required")]
        [StringLength(100, ErrorMessage = "Book Name can't be longer than 100 characters")]
        [Display(Name = "Book Name")]
        public string BookName { get; set; }

        [Required(ErrorMessage = "Price is required")]
        [DataType(DataType.Currency)]
        [Display(Name = "Price")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Author Name is required")]
        [StringLength(100, ErrorMessage = "Author Name can't be longer than 100 characters")]
        [Display(Name = "Author Name")]
        public string AuthorName { get; set; }

        [Required(ErrorMessage = "Category Name is required")]
        [StringLength(100, ErrorMessage = "Category Name can't be longer than 100 characters")]
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }

        [Required(ErrorMessage = "Availability is required")]
        [Display(Name = "Availability (Yes or No)")]
        public bool Availability { get; set; }

        [Required(ErrorMessage = "Published Year is required")]
        [DataType(DataType.Date)]
        [Display(Name = "Published Year")]
        public DateTime PublishedYear { get; set; }

        [Required(ErrorMessage = "Description is required")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Image URL is required")]
        [Display(Name = "Image URL")]
        public string ImageURL { get; set; }
    }
}
