﻿using EBook.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace EBook.Data
{
    public static class Seed
    {
        public static async Task SeedDataAsync(IApplicationBuilder app)
        {
            using (var serviceScope = app.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<AppDbContext>();

                // Ensure the database is created
                context.Database.EnsureCreated();

                // Seed Books
                if (!context.Books.Any())
                {
                    var random = new Random();
                    for (int i = 1; i <= 10; i++)
                    {
                        context.Books.Add(new Book
                        {
                            BookName = "Book " + i,
                            Price = random.Next(100, 500),
                            AuthorName = "Author " + i,
                            CategoryName = "Category " + i,
                            Availability = random.Next(0, 2) == 1,
                            PublishedYear = DateTime.Now.AddYears(-random.Next(1, 20)),
                            Description = "Description for book " + i,
                            ImageURL = "https://via.placeholder.com/150"
                        });
                    }
                    await context.SaveChangesAsync();
                }
            }
        }
    }
}
