﻿using System;

namespace EBook.Data.ViewModels
{
    public class DashboardViewModel
    {
        public int BooksCount { get; set; }
        public int OrdersCount { get; set; }
        public int UsersCount { get; set; }
        public int FeedbackCount { get; set; }
    }
}
