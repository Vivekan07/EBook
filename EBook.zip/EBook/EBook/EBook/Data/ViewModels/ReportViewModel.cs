﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EBook.Data.ViewModels
{

    public class ReportViewModel
    {
        public string UserName { get; set; }

        public List<SelectListItem> Users { get; set; }
    }
}
