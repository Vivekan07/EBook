﻿using EBook.Data.Static;
using EBook.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace EBook.Data.ViewModels
{
    public static class AppDbInitializer
    {
        public static async Task SeedUsersAndRolesAsync(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                var roleManager = serviceScope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
                var userManager = serviceScope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
                var loggerFactory = serviceScope.ServiceProvider.GetRequiredService<ILoggerFactory>();
                var logger = loggerFactory.CreateLogger("AppDbInitializer");

                // Create roles
                await EnsureRoleExists(roleManager, UserRoles.Admin, logger);
                await EnsureRoleExists(roleManager, UserRoles.User, logger);

                // Create admin users
                await EnsureUserExists(userManager, "admin@gmail.com", "admin-user", "Admin User", "Admin@123", UserRoles.Admin, logger);
                await EnsureUserExists(userManager, "admin2@gmail.com", "admin2-user", "Admin User 2", "Admin@1409", UserRoles.Admin, logger);

                // Create regular user
                await EnsureUserExists(userManager, "user@gmail.com", "app-user", "Application User", "Coding@1234?", UserRoles.User, logger);
            }
        }

        private static async Task EnsureRoleExists(RoleManager<IdentityRole> roleManager, string roleName, ILogger logger)
        {
            if (!await roleManager.RoleExistsAsync(roleName))
            {
                var result = await roleManager.CreateAsync(new IdentityRole(roleName));
                if (result.Succeeded)
                {
                    logger.LogInformation("Role {RoleName} created successfully.", roleName);
                }
                else
                {
                    logger.LogError("Error creating role {RoleName}: {Errors}", roleName, string.Join(", ", result.Errors));
                }
            }
        }

        private static async Task EnsureUserExists(UserManager<ApplicationUser> userManager, string email, string username, string fullName, string password, string role, ILogger logger)
        {
            var user = await userManager.FindByEmailAsync(email);
            if (user == null)
            {
                var newUser = new ApplicationUser
                {
                    FullName = fullName,
                    UserName = username,
                    Email = email,
                    EmailConfirmed = true
                };

                try
                {
                    var result = await userManager.CreateAsync(newUser, password);
                    if (result.Succeeded)
                    {
                        await userManager.AddToRoleAsync(newUser, role);
                        logger.LogInformation("User {Email} created successfully and added to role {Role}.", email, role);
                    }
                    else
                    {
                        logger.LogError("Error creating user {Email}: {Errors}", email, string.Join(", ", result.Errors));
                    }
                }
                catch (Exception ex)
                {
                    logger.LogError("Exception while creating user {Email}: {Exception}", email, ex);
                }
            }
            else
            {
                logger.LogInformation("User {Email} already exists.", email);
            }
        }
    }
}
