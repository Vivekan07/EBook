﻿using EBook.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EBook.Data.Services
{
    public interface IOrdersService
    {
        Task StoreOrderAsync(List<ShoppingCartItem> items, string userId, string userEmailAddress);
        Task<List<Order>> GetOrdersByUserIdAndRoleAsync(string userId, string userRole);
        Task<List<Order>> GetAllOrdersWithUserDetailsAsync(); // New method for admin report
    }
}
