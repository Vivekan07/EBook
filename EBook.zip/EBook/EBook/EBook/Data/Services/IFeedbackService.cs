﻿using EBook.Data.Base;
using EBook.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EBook.Data.Services
{
    public interface IFeedbackService : IEntityBaseRepository<Feedback>
    {
        Task<IEnumerable<Feedback>> GetFeedbackByBookIdAsync(int bookId);
        Task<IEnumerable<Feedback>> GetAllFeedbackAsync(); // Add this line
        Task AddFeedbackAsync(Feedback feedback);
        Task DeleteFeedbackAsync(int id);
    }
}
