﻿using EBook.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EBook.Data.Services
{
    public class OrdersService : IOrdersService
    {
        private readonly AppDbContext _context;

        public OrdersService(AppDbContext context)
        {
            _context = context;
        }

        // Stores an order with the specified items, user ID, and email address
        public async Task StoreOrderAsync(List<ShoppingCartItem> items, string userId, string userEmailAddress)
        {
            var order = new Order
            {
                UserId = userId,
                Email = userEmailAddress,
                OrderDate = DateTime.Now
            };
            await _context.Orders.AddAsync(order);
            await _context.SaveChangesAsync();

            foreach (var item in items)
            {
                var orderItem = new OrderItem
                {
                    Amount = item.Amount,
                    BookId = item.Book.Id,
                    OrderId = order.Id,
                    Price = (double)item.Book.Price
                };
                await _context.OrderItems.AddAsync(orderItem);
            }
            await _context.SaveChangesAsync();
        }

        // Retrieves orders by user ID, including order items and associated books
        public async Task<List<Order>> GetOrdersByUserIdAsync(string userId)
        {
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Book)
                .Where(o => o.UserId == userId)
                .ToListAsync();

            return orders;
        }

        // Retrieves orders based on user ID and role, includes order items, books, and user information
        public async Task<List<Order>> GetOrdersByUserIdAndRoleAsync(string userId, string userRole)
        {
            var ordersQuery = _context.Orders
                .Include(o => o.User) // Include User to access FullName and Email
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Book)
                .AsQueryable();

            if (userRole == "Admin")
            {
                // Admin can view all orders
                return await ordersQuery.ToListAsync();
            }
            else
            {
                // Non-admin users can only view their own orders
                return await ordersQuery.Where(o => o.UserId == userId).ToListAsync();
            }
        }

        // Retrieves all orders including user details for reporting purposes
        public async Task<List<Order>> GetAllOrdersWithUserDetailsAsync()
        {
            return await _context.Orders
                .Include(o => o.User) // Include User to retrieve FullName and Email
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Book)
                .ToListAsync();
        }
    }
}
