﻿using EBook.Data.Base;
using EBook.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EBook.Data.Services
{
    public interface IBooksService : IEntityBaseRepository<Book>
    {
        Task<IEnumerable<Book>> GetAllBooksAsync();
        Task<Book> GetBookByIdAsync(int id);
        Task AddBookAsync(Book book);
        Task UpdateBookAsync(Book book);
        Task DeleteBookAsync(int id);
    }
}
