﻿using EBook.Data.Base;
using EBook.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EBook.Data.Services
{
    public class FeedbackService : EntityBaseRepository<Feedback>, IFeedbackService
    {
        private readonly AppDbContext _context;

        public FeedbackService(AppDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Feedback>> GetFeedbackByBookIdAsync(int bookId)
        {
            return await _context.Feedbacks
                                 .Where(f => f.BookId == bookId)
                                 .Include(f => f.Book)
                                 .ToListAsync();
        }

        public async Task<IEnumerable<Feedback>> GetAllFeedbackAsync() // Implement this method
        {
            return await _context.Feedbacks
                                 .Include(f => f.Book)
                                 .Include(f => f.User)// Optionally include related data
                                 .ToListAsync();
        }

        public async Task AddFeedbackAsync(Feedback feedback)
        {
            await _context.Feedbacks.AddAsync(feedback);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteFeedbackAsync(int id)
        {
            var feedback = await _context.Feedbacks.FirstOrDefaultAsync(f => f.Id == id);
            if (feedback != null)
            {
                _context.Feedbacks.Remove(feedback);
                await _context.SaveChangesAsync();
            }
        }
    }
}
