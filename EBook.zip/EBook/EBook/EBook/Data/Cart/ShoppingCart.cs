﻿using EBook.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EBook.Data.Cart
{
    public class ShoppingCart
    {
        private readonly AppDbContext _context;
        public string ShoppingCartId { get; set; }
        public List<ShoppingCartItem> ShoppingCartItems { get; set; }

        public ShoppingCart(AppDbContext context)
        {
            _context = context;
        }

        public static ShoppingCart GetShoppingCart(IServiceProvider services)
        {
            ISession session = services.GetRequiredService<IHttpContextAccessor>()?.HttpContext.Session;
            var context = services.GetService<AppDbContext>();

            string cartId = session.GetString("CartId") ?? Guid.NewGuid().ToString();
            session.SetString("CartId", cartId);

            return new ShoppingCart(context) { ShoppingCartId = cartId };
        }

        public async Task AddToCartAsync(Book book, int amount)
        {
            var shoppingCartItem = await _context.ShoppingCartItems
                .SingleOrDefaultAsync(s => s.Book.Id == book.Id && s.ShoppingCartId == ShoppingCartId);

            if (shoppingCartItem == null)
            {
                shoppingCartItem = new ShoppingCartItem
                {
                    ShoppingCartId = ShoppingCartId,
                    Book = book,
                    Amount = amount
                };

                await _context.ShoppingCartItems.AddAsync(shoppingCartItem);
            }
            else
            {
                shoppingCartItem.Amount += amount;
            }

            await _context.SaveChangesAsync();
        }

        public async Task RemoveFromCartAsync(Book book)
        {
            var shoppingCartItem = await _context.ShoppingCartItems
                .SingleOrDefaultAsync(s => s.Book.Id == book.Id && s.ShoppingCartId == ShoppingCartId);

            if (shoppingCartItem != null)
            {
                if (shoppingCartItem.Amount > 1)
                {
                    shoppingCartItem.Amount--;
                }
                else
                {
                    _context.ShoppingCartItems.Remove(shoppingCartItem);
                }

                await _context.SaveChangesAsync();
            }
        }

        public async Task ClearShoppingCartAsync()
        {
            var cartItems = await _context.ShoppingCartItems
                .Where(cart => cart.ShoppingCartId == ShoppingCartId)
                .ToListAsync();

            _context.ShoppingCartItems.RemoveRange(cartItems);
            await _context.SaveChangesAsync();
        }

        public async Task<List<ShoppingCartItem>> GetShoppingCartItemsAsync()
        {
            return ShoppingCartItems ?? (ShoppingCartItems = await _context.ShoppingCartItems
                .Where(cart => cart.ShoppingCartId == ShoppingCartId)
                .Include(s => s.Book)
                .ToListAsync());
        }

        public decimal GetShoppingCartTotal()
        {
            var total = _context.ShoppingCartItems
                .Where(cart => cart.ShoppingCartId == ShoppingCartId)
                .Select(c => c.Book.Price * c.Amount)
                .Sum();

            return total;
        }
    }
}
