﻿using EBook.Data.Services;
using EBook.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EBook.Controllers
{
    [Authorize]
    public class FeedbackController : Controller
    {
        private readonly IFeedbackService _feedbackService;

        public FeedbackController(IFeedbackService feedbackService)
        {
            _feedbackService = feedbackService;
        }

        // GET: Feedback/Index
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var feedbackList = await _feedbackService.GetAllFeedbackAsync();
            return View(feedbackList ?? new List<Feedback>()); // Ensure a non-null model is passed to the view
        }

        // GET: Feedback/Create
        public IActionResult Create(int bookId)
        {
            var feedback = new Feedback { BookId = bookId };
            return View(feedback);
        }

        // POST: Feedback/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Feedback feedback)
        {
            if (ModelState.IsValid)
            {
                await _feedbackService.AddFeedbackAsync(feedback);
                return RedirectToAction("Index");
            }

            return View(feedback);
        }
    }
}
