﻿using EBook.Data;
using EBook.Data.Services;
using EBook.Data.Static;
using EBook.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace EBook.Controllers
{
    [Authorize(Roles = UserRoles.Admin)]
    public class BooksController : Controller
    {
        private readonly IBooksService _service;
        private readonly IFeedbackService _feedbackService;

        public BooksController(IBooksService service, IFeedbackService feedbackService)
        {
            _service = service;
            _feedbackService = feedbackService;
        }

        // GET: Books
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var allBooks = await _service.GetAllBooksAsync();
            return View(allBooks);
        }

        // GET: Books/Details/5
        [AllowAnonymous]
        public async Task<IActionResult> Details(int id)
        {
            var book = await _service.GetBookByIdAsync(id);
            if (book == null)
            {
                return NotFound();
            }

            // Load similar books for demonstration, filtering by the same category
            book.SimilarBooks = (System.Collections.Generic.List<Book>)await _service.GetAllBooksAsync();

            // Load feedback for the book
            ViewData["FeedbackList"] = await _feedbackService.GetFeedbackByBookIdAsync(id);

            return View(book);
        }

        // POST: Books/SubmitFeedback
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitFeedback(int bookId, string comments, int rating)
        {
            if (!ModelState.IsValid || bookId <= 0)
            {
                return RedirectToAction("Details", new { id = bookId });
            }

            var feedback = new Feedback
            {
                BookId = bookId,
                Comments = comments,
                Rating = rating,
                UserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value,
                
            };

            await _feedbackService.AddFeedbackAsync(feedback);
            return RedirectToAction("Details", new { id = bookId });
        }

        // GET: Books/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Books/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BookName,Price,AuthorName,CategoryName,Availability,PublishedYear,Description,ImageURL")] Book book)
        {
            if (ModelState.IsValid)
            {
                await _service.AddBookAsync(book);
                return RedirectToAction(nameof(Index));
            }
            return View(book);
        }

        // GET: Books/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var book = await _service.GetBookByIdAsync(id);
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

        // POST: Books/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,BookName,Price,AuthorName,CategoryName,Availability,PublishedYear,Description,ImageURL")] Book book)
        {
            if (id != book.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _service.UpdateBookAsync(book);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await BookExists(book.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(book);
        }

        // GET: Books/Filter
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Filter(string searchString)
        {
            var allBooks = await _service.GetAllBooksAsync();

            if (!string.IsNullOrEmpty(searchString))
            {
                var filteredBooks = allBooks.Where(b => b.BookName.Contains(searchString, StringComparison.OrdinalIgnoreCase) ||
                                                         b.AuthorName.Contains(searchString, StringComparison.OrdinalIgnoreCase) ||
                                                         b.CategoryName.Contains(searchString, StringComparison.OrdinalIgnoreCase)).ToList();
                return View(nameof(Index), filteredBooks);
            }

            return View(nameof(Index), allBooks);
        }

        // POST: Books/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteBookAsync(id);
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> BookExists(int id)
        {
            var book = await _service.GetBookByIdAsync(id);
            return book != null;
        }
    }
}
