﻿using EBook.Data;
using EBook.Data.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

public class HomeController : Controller
{
    private readonly AppDbContext _context;

    public HomeController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Landing()
    {
        var books = _context.Books.ToList();
        return View(books);
    }

    public IActionResult Index()
    {
        var model = new DashboardViewModel
        {
            BooksCount = _context.Books.Count(),
            OrdersCount = _context.Orders.Count(),
            UsersCount = _context.Users.Count(),
            FeedbackCount = _context.Feedbacks.Count() // Make sure Feedbacks DbSet is defined in AppDbContext
        };

        return View(model);
    }
}
